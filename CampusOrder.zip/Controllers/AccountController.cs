using System.Security.Claims;
using CampusOrder.Data;
using CampusOrder.Helpers;
using CampusOrder.Models;
using CampusOrder.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusOrder.Controllers;

public class AccountController : Controller
{
    private readonly AppDbContext _db;
    private readonly PasswordHasher<Member> _hasher = new();

    public AccountController(AppDbContext db) => _db = db;

    [HttpGet]
    public IActionResult Login(string? returnUrl)
    {
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var member = await _db.Members.FirstOrDefaultAsync(m => m.Account == vm.Account);

        if (member == null ||
            _hasher.VerifyHashedPassword(member, member.PasswordHash, vm.Password) == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError("", "帳號或密碼錯誤");
            return View(vm);
        }

        await SignInAsync(member);

        if (!string.IsNullOrEmpty(vm.ReturnUrl) && Url.IsLocalUrl(vm.ReturnUrl))
            return Redirect(vm.ReturnUrl);

        return member.Role == Roles.Student
            ? RedirectToAction("Index", "Home")
            : RedirectToAction("Index", "Dashboard");
    }

    [HttpGet]
    public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel vm)
    {
        if (await _db.Members.AnyAsync(m => m.Account == vm.Account))
            ModelState.AddModelError(nameof(vm.Account), "這個帳號已經有人使用");

        if (!ModelState.IsValid) return View(vm);

        var member = new Member { Account = vm.Account, Name = vm.Name, Role = Roles.Student };
        member.PasswordHash = _hasher.HashPassword(member, vm.Password);

        _db.Members.Add(member);
        await _db.SaveChangesAsync();

        await SignInAsync(member);
        TempData["Success"] = "註冊成功，歡迎使用！";
        return RedirectToAction("Index", "Home");
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync();
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }

    public IActionResult AccessDenied() => View();

    private async Task SignInAsync(Member member)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, member.Id.ToString()),
            new(ClaimTypes.Name, member.Name),
            new(ClaimTypes.Role, member.Role)
        };
        if (member.StoreId != null)
            claims.Add(new Claim("StoreId", member.StoreId.Value.ToString()));

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(new ClaimsPrincipal(identity));
    }
}
