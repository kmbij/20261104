using CampusOrder.Data;
using CampusOrder.Helpers;
using CampusOrder.Models;
using CampusOrder.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusOrder.Controllers;

[Authorize(Roles = Roles.Student)]
public class CartController : Controller
{
    private readonly AppDbContext _db;

    public CartController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        return View(await BuildCartAsync());
    }

    [HttpPost]
    public async Task<IActionResult> Add(int menuItemId, int quantity = 1)
    {
        var item = await _db.MenuItems.Include(m => m.Store)
            .FirstOrDefaultAsync(m => m.Id == menuItemId && m.IsAvailable);
        if (item == null) return NotFound();

        if (!item.Store.IsOpen)
        {
            TempData["Error"] = $"「{item.Store.Name}」目前休息中，無法點餐。";
            return RedirectToAction("Store", "Menu", new { id = item.StoreId });
        }

        quantity = Math.Clamp(quantity, 1, 20);
        var cart = HttpContext.Session.GetCart();

        if (cart.Count > 0)
        {
            var firstId = cart[0].MenuItemId;
            var cartStoreId = await _db.MenuItems.Where(m => m.Id == firstId).Select(m => m.StoreId).FirstOrDefaultAsync();
            if (cartStoreId != item.StoreId)
            {
                cart.Clear();
                TempData["Info"] = "購物車原本是另一間店的餐點，已清空並改放這間店的餐點。";
            }
        }

        var line = cart.FirstOrDefault(l => l.MenuItemId == menuItemId);
        if (line == null)
            cart.Add(new CartLine { MenuItemId = menuItemId, Quantity = quantity });
        else
            line.Quantity = Math.Min(line.Quantity + quantity, 20);

        HttpContext.Session.SetCart(cart);
        TempData["Success"] = $"已把「{item.Name}」加入購物車。";
        return RedirectToAction("Store", "Menu", new { id = item.StoreId });
    }

    [HttpPost]
    public IActionResult Update(int menuItemId, int quantity)
    {
        var cart = HttpContext.Session.GetCart();
        var line = cart.FirstOrDefault(l => l.MenuItemId == menuItemId);
        if (line != null)
        {
            if (quantity <= 0) cart.Remove(line);
            else line.Quantity = Math.Min(quantity, 20);
            HttpContext.Session.SetCart(cart);
        }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult Remove(int menuItemId)
    {
        var cart = HttpContext.Session.GetCart();
        cart.RemoveAll(l => l.MenuItemId == menuItemId);
        HttpContext.Session.SetCart(cart);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult Clear()
    {
        HttpContext.Session.ClearCart();
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Checkout(string? note)
    {
        var vm = await BuildCartAsync();
        if (vm.Rows.Count == 0 || vm.Store == null)
        {
            TempData["Error"] = "購物車是空的。";
            return RedirectToAction(nameof(Index));
        }
        if (!vm.Store.IsOpen)
        {
            TempData["Error"] = $"「{vm.Store.Name}」目前休息中，無法下單。";
            return RedirectToAction(nameof(Index));
        }
        if (note?.Length > 100)
        {
            TempData["Error"] = "備註最多 100 個字。";
            return RedirectToAction(nameof(Index));
        }

        var now = DateTime.Now;

        var todayCount = await _db.Orders.CountAsync(o => o.StoreId == vm.Store.Id && o.OrderedAt >= now.Date);
        var pickupNo = todayCount + 1;

        var order = new Order
        {
            MemberId = User.GetMemberId(),
            StoreId = vm.Store.Id,
            OrderedAt = now,
            Status = (int)OrderStatus.Pending,
            PickupNo = pickupNo,
            OrderNo = $"{now:yyyyMMdd}-{vm.Store.Id:00}{pickupNo:000}",
            Note = string.IsNullOrWhiteSpace(note) ? null : note.Trim(),
            TotalAmount = vm.Total,
            OrderItems = vm.Rows.Select(r => new OrderItem
            {
                MenuItemId = r.MenuItemId,
                ItemName = r.Name,
                UnitPrice = r.Price,
                Quantity = r.Quantity
            }).ToList()
        };

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();

        HttpContext.Session.ClearCart();
        TempData["Success"] = "下單成功！";
        return RedirectToAction("Details", "MyOrders", new { id = order.Id });
    }

    private async Task<CartViewModel> BuildCartAsync()
    {
        var cart = HttpContext.Session.GetCart();
        var vm = new CartViewModel();
        if (cart.Count == 0) return vm;

        var ids = cart.Select(l => l.MenuItemId).ToList();
        var items = await _db.MenuItems.Include(m => m.Store)
            .Where(m => ids.Contains(m.Id) && m.IsAvailable)
            .ToListAsync();

        foreach (var line in cart)
        {
            var item = items.FirstOrDefault(m => m.Id == line.MenuItemId);
            if (item == null) continue;
            vm.Store ??= item.Store;
            vm.Rows.Add(new CartRowViewModel
            {
                MenuItemId = item.Id,
                Name = item.Name,
                Price = item.Price,
                Quantity = line.Quantity
            });
        }
        return vm;
    }
}
