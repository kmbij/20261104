using CampusOrder.Data;
using CampusOrder.Helpers;
using CampusOrder.Models;
using CampusOrder.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusOrder.Controllers;

[Authorize(Roles = Roles.Backstage)]
public class DashboardController : Controller
{
    private readonly AppDbContext _db;

    public DashboardController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        int? storeId = User.IsInRole(Roles.Store) ? User.GetStoreId() : null;
        var today = DateTime.Today;

        var orders = _db.Orders.AsQueryable();
        var menuItems = _db.MenuItems.AsQueryable();
        if (storeId != null)
        {
            orders = orders.Where(o => o.StoreId == storeId);
            menuItems = menuItems.Where(m => m.StoreId == storeId);
        }

        var todayOrders = orders.Where(o => o.OrderedAt >= today && o.Status != (int)OrderStatus.Cancelled);

        var vm = new DashboardViewModel
        {
            TodayOrders = await todayOrders.CountAsync(),
            TodayRevenue = await todayOrders.SumAsync(o => (int?)o.TotalAmount) ?? 0,
            WaitingOrders = await orders.CountAsync(o => o.Status == (int)OrderStatus.Pending || o.Status == (int)OrderStatus.Preparing),
            MenuItemCount = await menuItems.CountAsync(m => m.IsAvailable),
            LatestOrders = await orders
                .Include(o => o.Member).Include(o => o.Store)
                .OrderByDescending(o => o.OrderedAt)
                .Take(6)
                .ToListAsync()
        };
        return View(vm);
    }
}
