using CampusOrder.Data;
using CampusOrder.Helpers;
using CampusOrder.Models;
using CampusOrder.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusOrder.Controllers;

public class MenuController : Controller
{
    private readonly AppDbContext _db;

    public MenuController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Store(int id, string? keyword)
    {
        var store = await _db.Stores.FindAsync(id);
        if (store == null) return NotFound();

        var query = _db.MenuItems.Where(m => m.StoreId == id && m.IsAvailable);

        if (!string.IsNullOrWhiteSpace(keyword))
            query = query.Where(m => m.Name.Contains(keyword.Trim()));

        var vm = new StoreMenuViewModel
        {
            Store = store,
            Keyword = keyword,
            Items = await query.OrderBy(m => m.Id).ToListAsync()
        };
        return View(vm);
    }
}
