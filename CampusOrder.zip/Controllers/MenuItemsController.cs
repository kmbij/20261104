using CampusOrder.Data;
using CampusOrder.Helpers;
using CampusOrder.Models;
using CampusOrder.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CampusOrder.Controllers;

[Authorize(Roles = Roles.Backstage)]
public class MenuItemsController : Controller
{
    private const int PageSize = 8;
    private readonly AppDbContext _db;

    public MenuItemsController(AppDbContext db) => _db = db;

    private int? MyStoreId => User.IsInRole(Roles.Store) ? User.GetStoreId() : null;

    public async Task<IActionResult> Index(string? keyword, int? storeId, string sort = "id_desc", int page = 1)
    {
        if (MyStoreId != null) storeId = MyStoreId;

        var query = _db.MenuItems
            .Include(m => m.Store)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(keyword))
            query = query.Where(m => m.Name.Contains(keyword.Trim()));

        if (storeId != null)
            query = query.Where(m => m.StoreId == storeId);

        query = sort switch
        {
            "name_asc" => query.OrderBy(m => m.Name),
            "name_desc" => query.OrderByDescending(m => m.Name),
            "price_asc" => query.OrderBy(m => m.Price).ThenBy(m => m.Id),
            "price_desc" => query.OrderByDescending(m => m.Price).ThenBy(m => m.Id),
            "id_asc" => query.OrderBy(m => m.Id),
            _ => query.OrderByDescending(m => m.Id)
        };

        var vm = new MenuItemListViewModel
        {
            Items = await PagedList<MenuItem>.CreateAsync(query, page, PageSize),
            Keyword = keyword,
            StoreId = storeId,
            Sort = sort,
            ShowStoreFilter = MyStoreId == null,
            Stores = new SelectList(await _db.Stores.OrderBy(s => s.Id).ToListAsync(), "Id", "Name", storeId)
        };
        return View(vm);
    }

    public async Task<IActionResult> Create()
    {
        var vm = new MenuItemFormViewModel { StoreId = MyStoreId };
        await FillSelectListsAsync(vm);
        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Create(MenuItemFormViewModel vm)
    {
        if (MyStoreId != null) vm.StoreId = MyStoreId;

        if (!ModelState.IsValid)
        {
            await FillSelectListsAsync(vm);
            return View(vm);
        }

        var item = new MenuItem
        {
            Name = vm.Name,
            Price = vm.Price!.Value,
            Description = vm.Description,
            StoreId = vm.StoreId!.Value,
            IsAvailable = vm.IsAvailable
        };

        _db.MenuItems.Add(item);
        await _db.SaveChangesAsync();

        TempData["Success"] = $"已新增餐點「{item.Name}」。";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var item = await FindMineAsync(id);
        if (item == null) return NotFound();

        var vm = new MenuItemFormViewModel
        {
            Id = item.Id,
            Name = item.Name,
            Price = item.Price,
            Description = item.Description,
            StoreId = item.StoreId,
            IsAvailable = item.IsAvailable
        };
        await FillSelectListsAsync(vm);
        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, MenuItemFormViewModel vm)
    {
        if (id != vm.Id) return BadRequest();

        var item = await FindMineAsync(id);
        if (item == null) return NotFound();

        if (MyStoreId != null) vm.StoreId = MyStoreId;

        if (!ModelState.IsValid)
        {
            await FillSelectListsAsync(vm);
            return View(vm);
        }

        item.Name = vm.Name;
        item.Price = vm.Price!.Value;
        item.Description = vm.Description;
        item.StoreId = vm.StoreId!.Value;
        item.IsAvailable = vm.IsAvailable;

        await _db.SaveChangesAsync();
        TempData["Success"] = $"已更新餐點「{item.Name}」。";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Details(int id)
    {
        var item = await FindMineAsync(id);
        if (item == null) return NotFound();
        return View(item);
    }

    public async Task<IActionResult> Delete(int id)
    {
        var item = await FindMineAsync(id);
        if (item == null) return NotFound();
        return View(item);
    }

    [HttpPost, ActionName("Delete")]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item = await FindMineAsync(id);
        if (item == null) return NotFound();

        if (await _db.OrderItems.AnyAsync(i => i.MenuItemId == id))
        {
            TempData["Error"] = $"「{item.Name}」已經有訂單紀錄，不能刪除。請改成「暫停供應」。";
            return RedirectToAction(nameof(Index));
        }

        _db.MenuItems.Remove(item);
        await _db.SaveChangesAsync();

        TempData["Success"] = $"已刪除餐點「{item.Name}」。";
        return RedirectToAction(nameof(Index));
    }

    private async Task<MenuItem?> FindMineAsync(int id)
    {
        var query = _db.MenuItems.Include(m => m.Store).Where(m => m.Id == id);
        if (MyStoreId != null) query = query.Where(m => m.StoreId == MyStoreId);
        return await query.FirstOrDefaultAsync();
    }

    private async Task FillSelectListsAsync(MenuItemFormViewModel vm)
    {
        var stores = _db.Stores.AsQueryable();
        if (MyStoreId != null) stores = stores.Where(s => s.Id == MyStoreId);
        vm.Stores = new SelectList(await stores.OrderBy(s => s.Id).ToListAsync(), "Id", "Name", vm.StoreId);
    }
}
