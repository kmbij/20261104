using CampusOrder.Data;
using CampusOrder.Helpers;
using CampusOrder.Models;
using CampusOrder.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusOrder.Controllers;

[Authorize(Roles = Roles.Student)]
public class MyOrdersController : Controller
{
    private readonly AppDbContext _db;

    public MyOrdersController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        var memberId = User.GetMemberId();
        var orders = await _db.Orders
            .Include(o => o.Store)
            .Include(o => o.OrderItems)
            .Where(o => o.MemberId == memberId)
            .OrderByDescending(o => o.OrderedAt)
            .ToListAsync();
        return View(orders);
    }

    public async Task<IActionResult> Details(int id)
    {
        var memberId = User.GetMemberId();
        var order = await _db.Orders
            .Include(o => o.Store)
            .Include(o => o.OrderItems)
            .FirstOrDefaultAsync(o => o.Id == id && o.MemberId == memberId);
        if (order == null) return NotFound();
        return View(order);
    }

    [HttpPost]
    public async Task<IActionResult> Cancel(int id)
    {
        var memberId = User.GetMemberId();
        var order = await _db.Orders.FirstOrDefaultAsync(o => o.Id == id && o.MemberId == memberId);
        if (order == null) return NotFound();

        if (order.Status != (int)OrderStatus.Pending)
        {
            TempData["Error"] = "店家已經開始製作，無法取消。";
        }
        else
        {
            order.Status = (int)OrderStatus.Cancelled;
            await _db.SaveChangesAsync();
            TempData["Success"] = "訂單已取消。";
        }
        return RedirectToAction(nameof(Details), new { id });
    }
}
