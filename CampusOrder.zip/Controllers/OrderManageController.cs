using CampusOrder.Data;
using CampusOrder.Helpers;
using CampusOrder.Models;
using CampusOrder.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusOrder.Controllers;

[Authorize(Roles = Roles.Backstage)]
public class OrderManageController : Controller
{
    private const int PageSize = 10;
    private readonly AppDbContext _db;

    public OrderManageController(AppDbContext db) => _db = db;

    private int? MyStoreId => User.IsInRole(Roles.Store) ? User.GetStoreId() : null;

    public async Task<IActionResult> Index(OrderStatus? status, string? keyword, int page = 1)
    {
        var query = _db.Orders
            .Include(o => o.Member)
            .Include(o => o.Store)
            .Include(o => o.OrderItems)
            .AsQueryable();

        if (MyStoreId != null)
            query = query.Where(o => o.StoreId == MyStoreId);

        if (status != null)
            query = query.Where(o => o.Status == (int)status);

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            query = query.Where(o => o.OrderNo.Contains(k) || o.Member.Name.Contains(k));
        }

        query = query.OrderByDescending(o => o.OrderedAt);

        var vm = new OrderListViewModel
        {
            Items = await PagedList<Order>.CreateAsync(query, page, PageSize),
            Status = status,
            Keyword = keyword
        };
        return View(vm);
    }

    public async Task<IActionResult> Details(int id)
    {
        var order = await FindMineAsync(id);
        if (order == null) return NotFound();
        return View(order);
    }

    [HttpPost]
    public async Task<IActionResult> ChangeStatus(int id, OrderStatus newStatus)
    {
        var order = await FindMineAsync(id);
        if (order == null) return NotFound();

        var current = (OrderStatus)order.Status;
        if (!NextStatuses(current).Contains(newStatus))
        {
            TempData["Error"] = $"訂單目前是「{current.DisplayName()}」，不能改成「{newStatus.DisplayName()}」。";
        }
        else
        {
            order.Status = (int)newStatus;
            await _db.SaveChangesAsync();
            TempData["Success"] = $"訂單 {order.OrderNo} 已改為「{newStatus.DisplayName()}」。";
        }
        return RedirectToAction(nameof(Details), new { id });
    }

    public static OrderStatus[] NextStatuses(OrderStatus current) => current switch
    {
        OrderStatus.Pending => new[] { OrderStatus.Preparing, OrderStatus.Cancelled },
        OrderStatus.Preparing => new[] { OrderStatus.Ready, OrderStatus.Cancelled },
        OrderStatus.Ready => new[] { OrderStatus.Completed },
        _ => Array.Empty<OrderStatus>()
    };

    private async Task<Order?> FindMineAsync(int id)
    {
        var query = _db.Orders
            .Include(o => o.Member)
            .Include(o => o.Store)
            .Include(o => o.OrderItems)
            .Where(o => o.Id == id);
        if (MyStoreId != null) query = query.Where(o => o.StoreId == MyStoreId);
        return await query.FirstOrDefaultAsync();
    }
}
