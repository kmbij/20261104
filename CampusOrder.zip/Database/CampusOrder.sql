﻿USE master;
GO

IF DB_ID(N'CampusOrder') IS NOT NULL
BEGIN
    ALTER DATABASE CampusOrder SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE CampusOrder;
END
GO

CREATE DATABASE CampusOrder;
GO

USE CampusOrder;
GO

CREATE TABLE Stores (
    Id           int IDENTITY(1,1) NOT NULL,
    Name         nvarchar(30)      NOT NULL,
    Location     nvarchar(50)      NOT NULL,
    Description  nvarchar(200)     NULL,
    IsOpen       bit               NOT NULL,
    CONSTRAINT PK_Stores PRIMARY KEY (Id)
);

CREATE TABLE MenuItems (
    Id           int IDENTITY(1,1) NOT NULL,
    Name         nvarchar(30)      NOT NULL,
    Price        int               NOT NULL,
    Description  nvarchar(200)     NULL,
    IsAvailable  bit               NOT NULL,
    StoreId      int               NOT NULL,
    CONSTRAINT PK_MenuItems PRIMARY KEY (Id),
    CONSTRAINT FK_MenuItems_Stores FOREIGN KEY (StoreId) REFERENCES Stores (Id)
);

CREATE TABLE Members (
    Id            int IDENTITY(1,1) NOT NULL,
    Account       nvarchar(20)      NOT NULL,
    PasswordHash  nvarchar(200)     NOT NULL,
    Name          nvarchar(20)      NOT NULL,
    Role          nvarchar(10)      NOT NULL,
    StoreId       int               NULL,
    CONSTRAINT PK_Members PRIMARY KEY (Id),
    CONSTRAINT UQ_Members_Account UNIQUE (Account),
    CONSTRAINT FK_Members_Stores FOREIGN KEY (StoreId) REFERENCES Stores (Id)
);

CREATE TABLE Orders (
    Id           int IDENTITY(1,1) NOT NULL,
    OrderNo      nvarchar(20)      NOT NULL,
    PickupNo     int               NOT NULL,
    OrderedAt    datetime2(0)      NOT NULL,
    Status       int               NOT NULL,
    TotalAmount  int               NOT NULL,
    Note         nvarchar(100)     NULL,
    MemberId     int               NOT NULL,
    StoreId      int               NOT NULL,
    CONSTRAINT PK_Orders PRIMARY KEY (Id),
    CONSTRAINT UQ_Orders_OrderNo UNIQUE (OrderNo),
    CONSTRAINT FK_Orders_Members FOREIGN KEY (MemberId) REFERENCES Members (Id),
    CONSTRAINT FK_Orders_Stores  FOREIGN KEY (StoreId)  REFERENCES Stores (Id)
);

CREATE TABLE OrderItems (
    Id          int IDENTITY(1,1) NOT NULL,
    OrderId     int               NOT NULL,
    MenuItemId  int               NOT NULL,
    ItemName    nvarchar(30)      NOT NULL,
    UnitPrice   int               NOT NULL,
    Quantity    int               NOT NULL,
    CONSTRAINT PK_OrderItems PRIMARY KEY (Id),
    CONSTRAINT FK_OrderItems_Orders    FOREIGN KEY (OrderId)    REFERENCES Orders (Id) ON DELETE CASCADE,
    CONSTRAINT FK_OrderItems_MenuItems FOREIGN KEY (MenuItemId) REFERENCES MenuItems (Id)
);
GO

SET IDENTITY_INSERT Stores ON;
INSERT INTO Stores (Id, Name, Location, Description, IsOpen) VALUES
    (1, N'好食便當', N'第一餐廳 1 樓', N'現做便當，每日三種主菜輪替。', 1),
    (2, N'麵麵俱到', N'第一餐廳 1 樓', N'湯麵、乾麵與手工水餃。', 1),
    (3, N'晨光輕食吧', N'圖書館旁', N'三明治、沙拉與現煮咖啡。', 1);
SET IDENTITY_INSERT Stores OFF;

SET IDENTITY_INSERT MenuItems ON;
INSERT INTO MenuItems (Id, Name, Price, Description, IsAvailable, StoreId) VALUES
    (1, N'招牌雞腿便當', 95, N'酥炸雞腿配三樣配菜。', 1, 1),
    (2, N'滷排骨便當', 90, N'古早味滷排骨。', 1, 1),
    (3, N'鯖魚便當', 100, N'鹽烤鯖魚，附味噌湯。', 1, 1),
    (4, N'咖哩豬排飯', 105, N'日式咖哩淋上現炸豬排。', 1, 1),
    (5, N'蔬食便當', 80, N'五樣時蔬，蛋奶素可食。', 1, 1),
    (6, N'古早味紅茶', 20, N'中杯，微糖。', 1, 1),
    (7, N'冬瓜檸檬', 30, N'中杯。', 1, 1),
    (8, N'紅燒牛肉麵', 130, N'牛腱心慢燉四小時。', 1, 2),
    (9, N'榨菜肉絲麵', 75, N'清爽湯頭。', 1, 2),
    (10, N'麻醬乾麵', 60, N'自製芝麻醬。', 1, 2),
    (11, N'炸醬麵', 65, N'豆乾丁炸醬。', 1, 2),
    (12, N'手工水餃（10 顆）', 70, N'高麗菜豬肉餡。', 1, 2),
    (13, N'燙青菜', 35, N'當日時蔬。', 1, 2),
    (14, N'酸梅湯', 25, N'中杯。', 1, 2),
    (15, N'火腿起司三明治', 55, N'現烤吐司。', 1, 3),
    (16, N'鮪魚蛋三明治', 60, N'鮪魚沙拉加水煮蛋。', 1, 3),
    (17, N'雞胸肉沙拉', 95, N'舒肥雞胸，附和風醬。', 1, 3),
    (18, N'美式咖啡', 50, N'中杯，可選冰熱。', 1, 3),
    (19, N'拿鐵', 65, N'中杯，可選冰熱。', 1, 3),
    (20, N'鮮奶茶', 55, N'中杯。', 1, 3),
    (21, N'巴斯克乳酪蛋糕', 75, N'每日限量。', 1, 3),
    (22, N'布朗尼', 45, N'暫停供應的示範資料。', 0, 3);
SET IDENTITY_INSERT MenuItems OFF;

SET IDENTITY_INSERT Members ON;
INSERT INTO Members (Id, Account, PasswordHash, Name, Role, StoreId) VALUES
    (1, N'admin', N'AQAAAAIAAYagAAAAEKvxQC1VjJsespNxEh8tds6Mos/qBGjhRWysKmo92PPjTNgHBvv/7fKdpeL36NmYXw==', N'系統管理員', N'Admin', NULL),
    (2, N'student1', N'AQAAAAIAAYagAAAAEPEBM3CxBK6ePZND1eXjwjhQvYmCz62Y+KTzAmu2lriffR2Ittvl0xlIUhc3tHVibA==', N'王小明', N'Student', NULL),
    (3, N'student2', N'AQAAAAIAAYagAAAAEHn28//sh/QsyL9hJBJ+NNa0r2RQvAFXHfe6/sYYGYO3QFjNXthibJwgTJ36kgRCmw==', N'陳怡君', N'Student', NULL),
    (4, N'store1', N'AQAAAAIAAYagAAAAEBPrOVUxX3MFWYogYQaVpQiZtWQA3TFhuxNYP3n2PpqJvsUzp9LwdAzO900r42KtaA==', N'好食便當 店長', N'Store', 1),
    (5, N'store2', N'AQAAAAIAAYagAAAAEJkwKXujEEC/5nZn/cqkFGDXgEd3I5Cp9qnBLMaEp+AhVk4R8LZYtjylEtHKgHxHHw==', N'麵麵俱到 店長', N'Store', 2),
    (6, N'store3', N'AQAAAAIAAYagAAAAEJjFaJ7wKHYVRGB2GVdfk3iht9fKpAZQ17UIMFED40UZ+FXjrMpj1Y4BFFgY6oMgWQ==', N'晨光輕食吧 店長', N'Store', 3);
SET IDENTITY_INSERT Members OFF;

DECLARE @today datetime2(0) = CAST(CAST(GETDATE() AS date) AS datetime2(0));
DECLARE @d0 char(8) = CONVERT(char(8), @today, 112);
DECLARE @d1 char(8) = CONVERT(char(8), DATEADD(DAY, -1, @today), 112);

SET IDENTITY_INSERT Orders ON;
INSERT INTO Orders (Id, OrderNo, PickupNo, OrderedAt, Status, TotalAmount, Note, MemberId, StoreId) VALUES
    (1, @d1 + N'-01001', 1, DATEADD(MINUTE, 690, DATEADD(DAY, -1, @today)), 3, 115, NULL, 2, 1),
    (2, @d1 + N'-02001', 1, DATEADD(MINUTE, 720, DATEADD(DAY, -1, @today)), 3, 130, N'不要香菜', 3, 2),
    (3, @d0 + N'-03001', 1, DATEADD(MINUTE, 492, @today), 3, 105, NULL, 2, 3),
    (4, @d0 + N'-01001', 1, DATEADD(MINUTE, 666, @today), 2, 210, NULL, 3, 1),
    (5, @d0 + N'-01002', 2, DATEADD(MINUTE, 678, @today), 1, 120, N'飯少一點', 2, 1),
    (6, @d0 + N'-01003', 3, DATEADD(MINUTE, 684, @today), 0, 220, NULL, 3, 1),
    (7, @d0 + N'-02001', 1, DATEADD(MINUTE, 690, @today), 0, 130, NULL, 2, 2),
    (8, @d0 + N'-03002', 2, DATEADD(MINUTE, 540, @today), 9, 65, N'臨時有事', 3, 3);
SET IDENTITY_INSERT Orders OFF;

INSERT INTO OrderItems (OrderId, MenuItemId, ItemName, UnitPrice, Quantity) VALUES
    (1, 1, N'招牌雞腿便當', 95, 1),
    (1, 6, N'古早味紅茶', 20, 1),
    (2, 8, N'紅燒牛肉麵', 130, 1),
    (3, 15, N'火腿起司三明治', 55, 1),
    (3, 18, N'美式咖啡', 50, 1),
    (4, 4, N'咖哩豬排飯', 105, 2),
    (5, 2, N'滷排骨便當', 90, 1),
    (5, 7, N'冬瓜檸檬', 30, 1),
    (6, 3, N'鯖魚便當', 100, 1),
    (6, 5, N'蔬食便當', 80, 1),
    (6, 6, N'古早味紅茶', 20, 2),
    (7, 10, N'麻醬乾麵', 60, 1),
    (7, 12, N'手工水餃（10 顆）', 70, 1),
    (8, 19, N'拿鐵', 65, 1);
GO

SELECT N'Stores' AS 資料表, COUNT(*) AS 筆數 FROM Stores
UNION ALL SELECT N'MenuItems', COUNT(*) FROM MenuItems
UNION ALL SELECT N'Members', COUNT(*) FROM Members
UNION ALL SELECT N'Orders', COUNT(*) FROM Orders
UNION ALL SELECT N'OrderItems', COUNT(*) FROM OrderItems;
GO
