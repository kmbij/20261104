using System.ComponentModel.DataAnnotations;

namespace CampusOrder.Helpers;

public static class Roles
{
    public const string Student = "Student";
    public const string Store = "Store";
    public const string Admin = "Admin";
    public const string Backstage = Store + "," + Admin;

    public static string Display(string role) => role switch
    {
        Student => "學生",
        Store => "店家",
        Admin => "管理員",
        _ => role
    };
}

public enum OrderStatus
{
    [Display(Name = "已下單")] Pending = 0,
    [Display(Name = "製作中")] Preparing = 1,
    [Display(Name = "可取餐")] Ready = 2,
    [Display(Name = "已完成")] Completed = 3,
    [Display(Name = "已取消")] Cancelled = 9
}
