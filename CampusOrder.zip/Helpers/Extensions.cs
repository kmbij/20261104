using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Security.Claims;
using System.Text.Json;
using CampusOrder.Models;
using CampusOrder.ViewModels;

namespace CampusOrder.Helpers;

public static class UserExtensions
{
    public static int GetMemberId(this ClaimsPrincipal user) =>
        int.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public static int? GetStoreId(this ClaimsPrincipal user) =>
        int.TryParse(user.FindFirstValue("StoreId"), out var id) ? id : null;
}

public static class CartSessionExtensions
{
    private const string Key = "Cart";

    public static List<CartLine> GetCart(this ISession session)
    {
        var json = session.GetString(Key);
        return json == null ? new List<CartLine>() : JsonSerializer.Deserialize<List<CartLine>>(json)!;
    }

    public static void SetCart(this ISession session, List<CartLine> cart) =>
        session.SetString(Key, JsonSerializer.Serialize(cart));

    public static void ClearCart(this ISession session) => session.Remove(Key);
}

public static class EnumExtensions
{
    public static string DisplayName(this Enum value) =>
        value.GetType().GetMember(value.ToString()).FirstOrDefault()
            ?.GetCustomAttribute<DisplayAttribute>()?.Name ?? value.ToString();

    public static OrderStatus GetStatus(this Order order) => (OrderStatus)order.Status;

    public static string BadgeClass(this OrderStatus status) => status switch
    {
        OrderStatus.Pending => "text-bg-warning",
        OrderStatus.Preparing => "text-bg-info",
        OrderStatus.Ready => "text-bg-success",
        OrderStatus.Completed => "text-bg-secondary",
        _ => "text-bg-light border"
    };
}
