﻿using System;
using System.Collections.Generic;

namespace CampusOrder.Models;

public partial class Member
{
    public int Id { get; set; }

    public string Account { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Role { get; set; } = null!;

    public int? StoreId { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

    public virtual Store? Store { get; set; }
}
