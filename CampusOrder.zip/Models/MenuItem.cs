﻿using System;
using System.Collections.Generic;

namespace CampusOrder.Models;

public partial class MenuItem
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int Price { get; set; }

    public string? Description { get; set; }

    public bool IsAvailable { get; set; }

    public int StoreId { get; set; }

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    public virtual Store Store { get; set; } = null!;
}
