﻿using System;
using System.Collections.Generic;

namespace CampusOrder.Models;

public partial class Order
{
    public int Id { get; set; }

    public string OrderNo { get; set; } = null!;

    public int PickupNo { get; set; }

    public DateTime OrderedAt { get; set; }

    public int Status { get; set; }

    public int TotalAmount { get; set; }

    public string? Note { get; set; }

    public int MemberId { get; set; }

    public int StoreId { get; set; }

    public virtual Member Member { get; set; } = null!;

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    public virtual Store Store { get; set; } = null!;
}
