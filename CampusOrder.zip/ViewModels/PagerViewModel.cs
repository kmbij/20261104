namespace CampusOrder.ViewModels;

public class PagerViewModel
{
    public int PageNumber { get; set; }
    public int TotalPages { get; set; }
    public int TotalCount { get; set; }
    public Dictionary<string, string?> RouteValues { get; set; } = new();

    public Dictionary<string, string?> For(int page)
    {
        var values = new Dictionary<string, string?>(RouteValues) { ["page"] = page.ToString() };
        return values;
    }
}
