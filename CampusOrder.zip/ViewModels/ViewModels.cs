using System.ComponentModel.DataAnnotations;
using CampusOrder.Helpers;
using CampusOrder.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CampusOrder.ViewModels;

public class LoginViewModel
{
    [Display(Name = "帳號")]
    [Required(ErrorMessage = "請輸入帳號")]
    public string Account { get; set; } = "";

    [Display(Name = "密碼")]
    [Required(ErrorMessage = "請輸入密碼")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public string? ReturnUrl { get; set; }
}

public class RegisterViewModel
{
    [Display(Name = "帳號")]
    [Required(ErrorMessage = "請輸入帳號")]
    [RegularExpression("^[A-Za-z0-9]{4,20}$", ErrorMessage = "帳號請用 4 到 20 個英文字母或數字")]
    public string Account { get; set; } = "";

    [Display(Name = "姓名")]
    [Required(ErrorMessage = "請輸入姓名")]
    [StringLength(20, ErrorMessage = "姓名最多 20 個字")]
    public string Name { get; set; } = "";

    [Display(Name = "密碼")]
    [Required(ErrorMessage = "請輸入密碼")]
    [StringLength(30, MinimumLength = 6, ErrorMessage = "密碼長度請在 6 到 30 個字之間")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Display(Name = "確認密碼")]
    [Required(ErrorMessage = "請再輸入一次密碼")]
    [Compare(nameof(Password), ErrorMessage = "兩次輸入的密碼不一樣")]
    [DataType(DataType.Password)]
    public string ConfirmPassword { get; set; } = "";
}

public class MenuItemFormViewModel
{
    public int Id { get; set; }

    [Display(Name = "餐點名稱")]
    [Required(ErrorMessage = "請輸入餐點名稱")]
    [StringLength(30, ErrorMessage = "餐點名稱最多 30 個字")]
    public string Name { get; set; } = "";

    [Display(Name = "價格")]
    [Required(ErrorMessage = "請輸入價格")]
    [Range(1, 9999, ErrorMessage = "價格請輸入 1 到 9999")]
    public int? Price { get; set; }

    [Display(Name = "說明")]
    [StringLength(200, ErrorMessage = "說明最多 200 個字")]
    public string? Description { get; set; }

    [Display(Name = "店家")]
    [Required(ErrorMessage = "請選擇店家")]
    public int? StoreId { get; set; }

    [Display(Name = "供應中")]
    public bool IsAvailable { get; set; } = true;

    public SelectList? Stores { get; set; }
}

public class MenuItemListViewModel
{
    public PagedList<MenuItem> Items { get; set; } = null!;

    public string? Keyword { get; set; }
    public int? StoreId { get; set; }
    public string Sort { get; set; } = "id_desc";

    public SelectList? Stores { get; set; }

    public bool ShowStoreFilter { get; set; }
}

public class StoreMenuViewModel
{
    public Store Store { get; set; } = null!;
    public List<MenuItem> Items { get; set; } = new();
    public string? Keyword { get; set; }
}

public class CartLine
{
    public int MenuItemId { get; set; }
    public int Quantity { get; set; }
}

public class CartRowViewModel
{
    public int MenuItemId { get; set; }
    public string Name { get; set; } = "";
    public int Price { get; set; }
    public int Quantity { get; set; }
    public int Subtotal => Price * Quantity;
}

public class CartViewModel
{
    public Store? Store { get; set; }
    public List<CartRowViewModel> Rows { get; set; } = new();
    public int Total => Rows.Sum(r => r.Subtotal);

    [Display(Name = "備註")]
    [StringLength(100, ErrorMessage = "備註最多 100 個字")]
    public string? Note { get; set; }
}

public class DashboardViewModel
{
    public int TodayOrders { get; set; }
    public int TodayRevenue { get; set; }
    public int WaitingOrders { get; set; }
    public int MenuItemCount { get; set; }
    public List<Order> LatestOrders { get; set; } = new();
}

public class OrderListViewModel
{
    public PagedList<Order> Items { get; set; } = null!;
    public OrderStatus? Status { get; set; }
    public string? Keyword { get; set; }
}
