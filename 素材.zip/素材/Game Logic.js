
//@input SceneObject coin1
//@input SceneObject coin2
//@input SceneObject coin3
//@input SceneObject successImage

// 紀錄硬幣原本的狀態
var coins = [
    script.coin1,
    script.coin2,
    script.coin3
];

var collected = [false, false, false];

var coinCount = 0;


// 每一幀檢查硬幣狀態
var updateEvent = script.createEvent("UpdateEvent");

updateEvent.bind(function() {

    for (var i = 0; i < 3; i++) {

        // 硬幣已經被 Disable
        if (!coins[i].enabled && !collected[i]) {

            collected[i] = true;
            coinCount++;

            print("Collected: " + coinCount + "/3");

        }
    }

    // 三枚硬幣全部蒐集
    if (coinCount === 3) {

        script.successImage.enabled = true;

        print("GAME CLEAR!");

        // 停止繼續檢查
        updateEvent.enabled = false;
    }

});
